package bankmanager;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import javax.swing.*;

public class Loginpage extends JFrame implements ActionListener{
    
    JLabel i1;
    JButton b1,b2,b3;
    JTextField tf;
    JPasswordField pf;
    

    String pn;
    Loginpage(){
        super("BANK MANAGEMENT SYSTEM");
        this.pn = pn;
        ImageIcon i1 = new ImageIcon("C:/Users/Venkat_Vatshal/OneDrive/Desktop/Shadow_fox/src/icon/bank.png");

        JLabel label1 = new JLabel("WELCOME TO AUT BANK");
        label1.setBounds(170,125,450,40);
        label1.setForeground(Color.WHITE);
        label1.setFont(new Font("Times New Roman",Font.BOLD,32));
        label1.setHorizontalAlignment(SwingConstants.CENTER);
        add(label1);

        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon img = new ImageIcon(i2);
        JLabel imag = new JLabel(img);
        imag.setBounds(350, 10, 100, 100);
        add(imag);



        ImageIcon il1 = new ImageIcon("C:/Users/Venkat_Vatshal/OneDrive/Desktop/Shadow_fox/src/icon/CARD 1.jpeg");
        Image il2 = il1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon ilmg = new ImageIcon(il2);
        JLabel ilmag = new JLabel(ilmg);
        ilmag.setBounds(650, 320, 105, 75);
        add(ilmag);

        JLabel l2 = new JLabel("Card_No :");
        l2.setBounds(150, 190, 100, 50);
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("Times New Roman",Font.PLAIN,21));
        add(l2);

        tf = new JTextField(15);
        tf.setBounds(250, 200, 300, 25);
        tf.setFont(new Font("Arial",Font.BOLD,14));
        add(tf);


        JLabel l3 = new JLabel("Password :");
        l3.setBounds(150,220,100,50);
        l3.setForeground(Color.WHITE);
        l3.setFont(new Font("Times New Roman",Font.PLAIN,20));
        add(l3);

        pf = new JPasswordField(15);
        pf.setBounds(250, 230, 300, 25);
        add(pf);

        b1 = new JButton("SIGN IN");
        b1.setBounds(255, 260, 130, 35);
        b1.setForeground(Color.BLACK);
        b1.setHorizontalAlignment(SwingConstants.CENTER);
        b1.setFont(new Font("Calibri",Font.BOLD,16));
        b1.setBackground(Color.WHITE);
        b1.addActionListener(this);
        add(b1);

        
        b2 = new JButton("CLEAR");
        b2.setBounds(415,260,130,35);
        b2.setForeground(Color.BLACK);
        b2.setHorizontalAlignment(SwingConstants.CENTER);
        b2.setFont(new Font("Calibri",Font.BOLD,16));
        b2.setBackground(Color.WHITE);
        b2.addActionListener(this);
        add(b2);

        b3 = new JButton("SIGNUP");
        b3.setBounds(255, 300, 290, 35);
        b3.setForeground(Color.BLACK);
        b3.setHorizontalAlignment(SwingConstants.CENTER);
        b3.setFont(new Font("Calibri",Font.BOLD,16));
        b3.setBackground(Color.WHITE);
        b3.addActionListener(this);
        add(b3);

        ImageIcon ill1 = new ImageIcon("C:/Users/Venkat_Vatshal/OneDrive/Desktop/Shadow_fox/src/icon/bbb1.jpg");
        Image ill2 = ill1.getImage().getScaledInstance(850, 450, Image.SCALE_DEFAULT);
        ImageIcon illmg = new ImageIcon(ill2);
        JLabel illmag = new JLabel(illmg);
        illmag.setBounds(0, 0, 800, 450);
        add(illmag);

        

        

        setLayout(null);
        setSize(800, 450);
        setLocation(350, 200);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == b1){
                Conn c = new Conn();
                //String cardno = tf.getText();
                //String passcode = new String(pf.getPassword());

                String cardno = tf.getText().trim();
                String passcode = new String(pf.getPassword()).trim();



                String q = "select * from login where card_no = '"+cardno+"' and pass = '"+passcode+"'";
                ResultSet rs = c.statement.executeQuery(q);

                if (rs.next()){
                    System.out.println("Login Successful! Opening the next Screen");
                    setVisible(false);
                    
                    new main_screen(pn);
                }else{
                    JOptionPane.showMessageDialog(null, "Invalid Card Number or Password");
                    System.out.println("Invalid Card Number or Password");
                }
            }else if(e.getSource() == b2){
                tf.setText("");
                pf.setText("");
            }else{
                new SignUp();
                setVisible(false);
            }
        } catch (Exception E) {
            E.printStackTrace();
        }
        
    }
    public static void main(String[] args) {
        new Loginpage();
    }
}


