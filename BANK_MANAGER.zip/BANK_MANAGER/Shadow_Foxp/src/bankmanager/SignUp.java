package bankmanager;



import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class SignUp extends JFrame implements ActionListener{

    JTextField tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8,tf9,tf10;
    JRadioButton r1,r2,r3,r4,r5;
    JButton b1;
    int rand = (int)(Math.random() * 9000) +1000;
    String four = String.valueOf(rand);
     
    SignUp(){
        super("Application Form");
        ImageIcon i1 = new ImageIcon("C:/Users/Venkat_Vatshal/OneDrive/Desktop/Shadow_fox/src/icon/bank.png");

        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon img = new ImageIcon(i2);
        JLabel imag = new JLabel(img);
        imag.setBounds(25, 10, 100, 100);
        add(imag);

        

        JLabel l1 = new JLabel("Application Number: "+four);
        l1.setBounds(140, 10, 350, 50);
        l1.setFont(new Font("Times New Roman",Font.BOLD,30));
        l1.setForeground(new Color(232,217,196));
        add(l1);

        
        JLabel l2 = new JLabel("Page 1");
        l2.setBounds(590,5,50,25);
        l2.setFont(new Font("Calibri",Font.PLAIN,12));
        l2.setForeground(Color.WHITE);
        add(l2);

        JLabel l3 = new JLabel("Personal Information");
        l3.setBounds(160, 80, 400, 40);
        l3.setFont(new Font("Times New Roman",Font.PLAIN,24));
        l3.setForeground(new Color(232,217,196));
        add(l3);

        JLabel l4 = new JLabel("Full Name :");
        l4.setBounds(25,150,150,25);
        l4.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l4.setForeground(new Color(232,217,196));
        add(l4);

        tf1 = new JTextField(24);
        tf1.setBounds(185, 150, 450, 25);
        tf1.setBackground(Color.WHITE);
        tf1.setFont(new Font("Calibri",Font.BOLD,18));
        add(tf1);


        JLabel l5 = new JLabel("Father's Name :");
        l5.setBounds(25, 190, 150, 25);
        l5.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l5.setForeground(new Color(232,217,196));
        add(l5);


        tf2 = new JTextField(24);
        tf2.setBounds(185, 190, 450, 25);
        tf2.setBackground(Color.WHITE);
        tf2.setFont(new Font("Calibri",Font.BOLD,18));
        add(tf2);

        JLabel l6 = new JLabel("Mother's Name :");
        l6.setBounds(25, 230, 150, 25);
        l6.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l6.setForeground(new Color(232,217,196));
        add(l6);

        tf3 = new JTextField(24);
        tf3.setBounds(185, 230, 450, 25);
        tf3.setBackground(Color.WHITE);
        tf3.setFont(new Font("Calibri",Font.BOLD,18));
        add(tf3);
 
        
        JLabel l7 = new JLabel("Date Of Birth :");
        l7.setBounds(25,270,150,25);
        l7.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l7.setForeground(new Color(232,217,196));
        add(l7);

       /*  Dated = new JDateChooser();
        Dated.setBounds(185, 270, 130, 25);
        Dated.setForeground(Color.white);
        Dated.setFont(new Font("Calibri",Font.PLAIN,18));
        add(Dated); */

        tf4 = new JTextField("yyyy/mm/dd");
        tf4.setBounds(185, 270, 160, 25);
        tf4.setBackground(Color.WHITE);
        tf4.setFont(new Font("Cambria",Font.PLAIN,16));
        add(tf4);

        JLabel l8 = new JLabel("Gender :");
        l8.setBounds(400,270,100,25);
        l8.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l8.setForeground(new Color(232,217,196));
        add(l8);

        r1 = new JRadioButton("Male");
        r1.setBounds(470, 270, 70, 25);
        r1.setForeground(Color.WHITE);
        r1.setFont(new Font("Cambria",Font.BOLD,14));
        r1.setBackground(new Color(62,22,12));
        add(r1);

        r2 = new JRadioButton("Female");
        r2.setBounds(550, 270, 80, 25);
        r2.setForeground(Color.WHITE);
        r2.setFont(new Font("Cambria",Font.BOLD,14));
        r2.setBackground(new Color(62,22,12));
        add(r2);

        ButtonGroup bg = new ButtonGroup();
        bg.add(r1);
        bg.add(r2);

        JLabel l9 = new JLabel("Email_ID :");
        l9.setBounds(25, 310, 150, 25);
        l9.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l9.setForeground(new Color(232,217,196));
        add(l9);

        tf5 = new JTextField(24);
        tf5.setBounds(185, 310, 450, 25);
        tf5.setBackground(Color.WHITE);
        tf5.setFont(new Font("Calibri",Font.BOLD,18));
        add(tf5);


        JLabel l0 = new JLabel("Martial Status :");
        l0.setBounds(25, 350, 150, 25);
        l0.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l0.setForeground(new Color(232,217,196));
        add(l0);

        r3 = new JRadioButton("Married");
        r3.setBounds(185,350,120,25);
        r3.setForeground(Color.WHITE);
        r3.setBackground(new Color(62,22,12));
        r3.setFont(new Font("Times New Roman",Font.PLAIN,18));
        add(r3);

        r4 = new JRadioButton("Unmarried");
        r4.setBounds(325,350,150,25);
        r4.setForeground(Color.WHITE);
        r4.setBackground(new Color(62,22,12));
        r4.setFont(new Font("Times New Roman",Font.PLAIN,18));
        add(r4);

        r5 = new JRadioButton("Other");
        r5.setBounds(475,350,150,25);
        r5.setForeground(Color.WHITE);
        r5.setBackground(new Color(62,22,12));
        r5.setFont(new Font("Times New Roman",Font.PLAIN,18));
        add(r5);

        ButtonGroup bg1 = new ButtonGroup();
        bg1.add(r3);
        bg1.add(r4);
        bg1.add(r5);


        JLabel l11 = new JLabel("Address :");
        l11.setBounds(25, 390, 150, 25);
        l11.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l11.setForeground(new Color(232,217,196));
        add(l11);

        tf6 = new JTextField(24);
        tf6.setBounds(185, 390, 450, 25);
        tf6.setBackground(Color.WHITE);
        tf6.setFont(new Font("Calibri",Font.BOLD,18));
        add(tf6);

        JLabel l12 = new JLabel("City :");
        l12.setBounds(25, 430, 150, 25);
        l12.setFont(new Font ("Times New Roman",Font.PLAIN,20));
        l12.setForeground(new Color(232,217,196));
        add(l12);

        tf7 = new JTextField(20);
        tf7.setBounds(185,430,165,25);
        tf7.setForeground(Color.BLACK);
        tf7.setFont(new Font("Calibri",Font.BOLD,18));
        add(tf7);

        JLabel l13 = new JLabel("State :");
        l13.setBounds(370,430,100,25);
        l13.setFont(new Font("Times New Roman", Font.PLAIN,20));
        l13.setForeground(new Color(232,217,196));
        add(l13);

        tf8 = new JTextField();
        tf8.setBounds(440,430,200,25);
        tf8.setForeground(Color.BLACK);
        tf8.setFont(new Font("Calibri",Font.BOLD,18));
        add(tf8);

        JLabel l15 = new JLabel("Mandal ");
        l15.setBounds(25,470,100,25);
        l15.setForeground(new Color(232,217,196));
        l15.setFont(new Font("Times New Roman",Font.PLAIN,20));
        add(l15);

        tf9 = new JTextField();
        tf9.setBounds(185,470,165,25);
        tf9.setForeground(Color.BLACK);
        tf9.setFont(new Font("Calibri",Font.BOLD,18));
        add(tf9);

        JLabel l14 = new JLabel("PinCode");
        l14.setBounds(370,470,90,25);
        l14.setFont(new Font("Times New Roman", Font.PLAIN,18));
        l14.setForeground(new Color(232,217,196));
        add(l14);

        tf10 = new JTextField(20);
        tf10.setBounds(440,470,200,25);
        tf10.setForeground(Color.BLACK);
        tf10.setFont(new Font("Calibri",Font.PLAIN,18));
        add(tf10);


        b1 = new JButton("Next");
        b1.setBounds(540,520,100,25);
        b1.setBackground(new Color(62,22,12));
        b1.setForeground(new Color(232,217,196));
        b1.setFont(new Font("Times NEw Roman",Font.BOLD,20));
        b1.addActionListener(this);
        add(b1);
        
        getContentPane().setBackground(new Color(62,22,12));
        setLocation(440,110);
        setSize(680,600);
        setLayout(null);
        setUndecorated(true);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public static void main(String args[]){
        new SignUp();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == b1){
                String form = four;
                String name = tf1.getText();
                String fname = tf2.getText();
                String mname = tf3.getText();
                String dobd = tf4.getText();
                String gen = null;
                if (r1.isSelected()){
                    gen = "Male";
                }else{
                    gen = "Female";
                }
                String mail = tf5.getText();
                String stat = null;
                if (r3.isSelected()){
                    stat = "Married";
                }else if (r4.isSelected()){
                    stat = "Unmarried";
                }else{
                    stat = "Other";
                }
                String Addre = tf6.getText();
                String livcity = tf7.getText();
                String Statee = tf8.getText();
                String manda = tf9.getText();
                String pane = tf10.getText();


                try {
                    if (tf1.getText().equals("")){
                        JOptionPane.showMessageDialog(null, "Fill this field.");
                    }else{
                        Conn con1 = new Conn();
                        String v = "insert into DataBank values('"+form+"','"+name+"','"+fname+"','"+mname+"','"+dobd+"','"+gen+"','"+mail+"','"+stat+"','"+Addre+"','"+livcity+"','"+Statee+"','"+manda+"','"+pane+"')";
                        con1.statement.executeUpdate(v);
                        new SignedUp(four);
                        setVisible(false);
                    }
                } catch (Exception E) {
                    E.printStackTrace();
                }
            }
        } catch (Exception E) {
            E.printStackTrace();
        }
    }
}