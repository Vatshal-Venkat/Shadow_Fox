package bankmanager;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class main_screen extends JFrame implements ActionListener{

    JButton b1,b2,b3,b4,b5,b6,b7;
    String pn;
    main_screen(String pn){
        this.pn = pn;

        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icon/AuTuM.png"));
        Image i2 = i1.getImage().getScaledInstance(1550, 1080, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l1 = new JLabel(i3);
        l1.setBounds(0, 0, 1530, 800);
        add(l1);

        JLabel l2 = new JLabel("Select your Transaction");
        l2.setBounds(450,80,800,150);
        l2.setFont(new Font("System",Font.BOLD,28));
        l2.setForeground(Color.WHITE);
        l1.add(l2);

        b1 = new JButton("Deposit");
        b1.setBounds(350, 215, 200, 40);
        b1.setFont(new Font("System",Font.BOLD,18));
        b1.setBackground(new Color(65,125,128));
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        l1.add(b1);

        b2 = new JButton("Cash Withdrawal");
        b2.setBounds(670, 215, 200, 40);
        b2.setFont(new Font("System",Font.BOLD,18));
        b2.setBackground(new Color(65,125,128));
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);
        l1.add(b2);

        b3 = new JButton("Fast Cash");
        b3.setBounds(350, 275, 200, 40);
        b3.setFont(new Font("System",Font.BOLD,18));
        b3.setBackground(new Color(65,125,128));
        b3.setForeground(Color.WHITE);
        b3.addActionListener(this);
        l1.add(b3);

        b4 = new JButton("Mini Statement");
        b4.setBounds(670, 275, 200, 40);
        b4.setFont(new Font("System",Font.BOLD,18));
        b4.setBackground(new Color(65,125,128));
        b4.setForeground(Color.WHITE);
        b4.addActionListener(this);
        l1.add(b4);

        b5 = new JButton("Pin Change");
        b5.setBounds(350, 335, 200, 40);
        b5.setFont(new Font("System",Font.BOLD,18));
        b5.setBackground(new Color(65,125,128));
        b5.setForeground(Color.WHITE);
        b5.addActionListener(this);
        l1.add(b5);

        b6 = new JButton("Balance Enquiry");
        b6.setBounds(670, 335, 200, 40);
        b6.setFont(new Font("System",Font.BOLD,18));
        b6.setBackground(new Color(65,125,128));
        b6.setForeground(Color.WHITE);
        b6.addActionListener(this);
        l1.add(b6);

        b7 = new JButton("EXIT");
        b7.setBounds(670, 395, 200, 40);
        b7.setFont(new Font("System",Font.BOLD,18));
        b7.setBackground(new Color(65,125,128));
        b7.setForeground(Color.WHITE);
        b7.addActionListener(this);
        l1.add(b7);

        setLayout(null);
        setVisible(true);
        setLocation(0, 0);
        setSize(1550,1080);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }

    public static void main(String args[]){
        new main_screen("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        try {
            if(e.getSource()==b1){
                setVisible(false);
                new Deposit(pn);
            }else if (e.getSource()==b2){
                setVisible(false);
                new Withdraw(pn);

            }else if (e.getSource() == b3){
                setVisible(false);
                new FastCash(pn);
            }else if (e.getSource() == b4){
                new MiniS(pn);
                setVisible(false);
            }
            else if (e.getSource() == b5){
                new pinEx(pn);
                setVisible(false);
            }
            else if (e.getSource() == b6){
                setVisible(false);
                new Balance(pn);
            }else if(e.getSource() == b7){
                System.exit(0);
            }
            
        } catch (Exception E) {
            System.out.println(E);
            E.printStackTrace();
        }
    }
}
