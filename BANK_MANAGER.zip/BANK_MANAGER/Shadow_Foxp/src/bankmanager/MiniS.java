package bankmanager;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;

public class MiniS extends JFrame implements ActionListener{

    String pn;
    JButton button;
    JLabel l1,l2,l3,l4;

    MiniS(String pn){

        this.pn = pn;
        setLayout(null);

        l1 = new JLabel("AUT BANK");
        l1.setBounds(165, 30, 200, 25); 

        l1.setForeground(new Color(254,215,165));
        l1.setFont(new Font("Times New Roman", Font.BOLD, 28));
        add(l1);

        l2 = new JLabel();
        l2.setBounds(40,100,600,25);
        l2.setFont(new Font("Cambria",Font.BOLD,20 ));
        l2.setForeground(new Color(254,215,165));
        add(l2);

        l3 = new JLabel();
        l3.setBounds(40,130,400,400);
        l3.setFont(new Font("Cambria",Font.BOLD,15));
        l3.setForeground(new Color(254,215,165));
        add(l3);


        l4 = new JLabel();
        l4.setBounds(40,500,200,25);
        l4.setFont(new Font("Cambria",Font.BOLD,15));
        l4.setForeground(new Color(254,215,165));
        add(l4);


        try {
            Conn c = new Conn();
            PreparedStatement pst = c.connection.prepareStatement("SELECT * FROM login WHERE pass = ?");
            pst.setString(1, pn);
            ResultSet resultSet = pst.executeQuery();
            if (resultSet.next()) {
                String cardNo = resultSet.getString("card_no");
                l2.setText("Card Number: " + cardNo.substring(0, 4) + "XXXXXXXX" + cardNo.substring(11));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            int bal = 0;
            Conn c = new Conn();
            PreparedStatement pst = c.connection.prepareStatement("SELECT * FROM dep WHERE pin = ?");
            pst.setString(1, pn);
            ResultSet resultSet = pst.executeQuery();
            StringBuilder sb = new StringBuilder("<html>");
            while (resultSet.next()) {
                String date = resultSet.getString("date");
                String time = resultSet.getString("Timestate");
                String type = resultSet.getString("type");
                String amount = resultSet.getString("amount");
                
                sb.append(date).append(" &nbsp;&nbsp;").append(time).append(" &nbsp;&nbsp;")
                  .append(type).append(" &nbsp;&nbsp;").append(amount).append("<br><br>");
                
                if ("Deposit".equals(type)) {
                    bal += Integer.parseInt(amount);
                } else if ("Withdrawl".equals(type)) {
                    bal -= Integer.parseInt(amount);
                }
            }
            sb.append("</html>");
            l3.setText(sb.toString());
            l4.setText("Your total balance is: " + bal);
        } catch (Exception e) {
            e.printStackTrace();
        }


        button = new JButton("EXIT");
        button.setBounds(20,600,100,25);
        button.setForeground(new Color(254,215,165));
        button.setBackground(new Color(62,22,12));
        button.setFont(new Font("Cambria",Font.PLAIN,20));
        button.addActionListener(this);
        add(button);


        getContentPane().setBackground(new Color(62,22,12));
        setSize(500, 700);
        setLocation(520, 40);
        setUndecorated(true);
        setVisible(true);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        setVisible(false);
    }

    public static void main(String[] args) {
        new MiniS("");
    }

    
}
