package bankmanager;

import java.awt.*;
import java.awt.event.*;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.TimeZone;
import javax.swing.*;




public class Deposit extends JFrame implements ActionListener {
    String pn;
    TextField tf1;
    JButton b1,b2;
    Deposit(String pn){
        super("Deposit");
        this.pn = pn;

        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icon/AuTuM.png"));
        Image i2 = i1.getImage().getScaledInstance(1550, 1080, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l1 = new JLabel(i3);
        l1.setBounds(0, 0, 1530, 800);
        add(l1);


        JLabel l2 = new JLabel("ENTER THE AMOUNT YOU WANT TO DEPOSIT :");
        l2.setBounds(400, 100, 500, 25);
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("System",Font.BOLD,18));
        l1.add(l2);

        tf1 = new TextField();
        tf1.setBounds(450, 150, 300, 25);
        tf1.setFont(new Font("Times New Roman",Font.PLAIN,20));
        tf1.setBackground(new Color(65,125,128));
        tf1.setForeground(Color.BLACK);
        l1.add(tf1);

        b1 = new JButton("DEPOSIT");
        b1.setBounds(670, 335, 200, 40);
        b1.setBackground(new Color(65,125,128));
        b1.setForeground(Color.white);
        b1.setFont(new Font("System",Font.BOLD,20));
        b1.addActionListener(this);
        l1.add(b1);
 
        b2 = new JButton("BACK");
        b2.setBounds(670, 395, 200, 40);
        b2.setBackground(new Color(65,125,128));
        b2.setForeground(Color.white);
        b2.setFont(new Font("System",Font.BOLD,20));
        b2.addActionListener(this);
        l1.add(b2);

        setLayout(null);
        setSize(1550, 1080);
        setLocation(0, 0);
        setVisible(true);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try{
            String amount = tf1.getText();
            Date date = new Date(System.currentTimeMillis());
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            TimeZone istTimeZone = TimeZone.getTimeZone("Asia/Kolkata");
            if (e.getSource() == b1){
                if (tf1.getText().isEmpty()){
                    JOptionPane.showMessageDialog(null, "PLEASE ENTER THE AMOUNT");
                }else{
                    Conn c = new Conn();
                    c.statement.executeUpdate("insert into dep values('"+pn+"','"+date+"','"+timestamp+"','Deposit','"+amount+"')");
                    JOptionPane.showMessageDialog(null, "Rs "+amount+" DEPOSITTED SUCCESSFULLY");
                    setVisible(false);
                    new main_screen(pn);
                }
            }else if (e.getSource() == b2){
                setVisible(false);
                new main_screen(pn);
            }
        }catch(Exception E){
            E.printStackTrace();
        }
    }
    public static void main(String[] args) {
        new Deposit("");
    }
}
