package bankmanager;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import javax.swing.*;

public class Balance extends JFrame implements ActionListener{
    JButton b2;
    JLabel l3;
    String pn;
    Balance(String pn){
        this.pn = pn;
        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icon/AuTuM.png"));
        Image i2 = i1.getImage().getScaledInstance(1550, 1080, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l1 = new JLabel(i3);
        l1.setBounds(0, 0, 1530, 800);
        add(l1);


        JLabel l2 = new JLabel("Your current Balance is Rs.");
        l2.setBounds(400, 150, 700, 35);
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("System",Font.BOLD,25));
        l1.add(l2);

        l3 = new JLabel();
        l3.setBounds (470, 200, 400, 50);
        l3.setFont(new Font("System",Font.BOLD,25));
        l3.setForeground(Color.WHITE);
        l1.add(l3);

        
        b2 = new JButton("BACK");
        b2.setBounds(670, 395, 200, 40);
        b2.setBackground(new Color(65,125,128));
        b2.setForeground(Color.white);
        b2.setFont(new Font("System",Font.BOLD,20));
        b2.addActionListener(this);
        l1.add(b2);
        
        int bal = 0;
        try {
            Conn c = new Conn();
            ResultSet rs = c.statement.executeQuery("select * from dep where pin = '"+pn+"'");
            

            while (rs.next()){
                if (rs.getString("type").equals("Deposit")){
                    bal = bal + Integer.parseInt(rs.getString("amount"));

                }else{
                    bal -= Integer.parseInt(rs.getString("amount"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        

        l3.setText(""+bal);


        setLayout(null);
        setSize(1550, 1080);
        setLocation(0, 0);
        setVisible(true);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == b2) {
                setVisible(false);
                new main_screen(pn);
            }
        } catch (Exception E) {
            E.printStackTrace();
        }
    }

    public static void main(String args[]){
        new Balance("");
    }
}
