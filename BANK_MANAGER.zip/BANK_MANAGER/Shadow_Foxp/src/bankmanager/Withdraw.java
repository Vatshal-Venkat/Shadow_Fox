package bankmanager;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.TimeZone;
import javax.swing.*;

public class Withdraw extends JFrame implements ActionListener{

    String pn;
    TextField tf1;
    JButton b1,b2;


    Withdraw(String pn){
        this.pn=pn;
        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icon/AuTuM.png"));
        Image i2 = i1.getImage().getScaledInstance(1550, 1080, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l1 = new JLabel(i3);
        l1.setBounds(0, 0, 1530, 800);
        add(l1);


        JLabel l2 = new JLabel("ENTER THE AMOUNT YOU WANT TO DRAW:");
        l2.setBounds(400, 100, 500, 25);
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("System",Font.BOLD,18));
        l1.add(l2);

        tf1 = new TextField();
        tf1.setBounds(450, 150, 300, 25);
        tf1.setFont(new Font("Times New Roman",Font.PLAIN,20));
        tf1.setBackground(new Color(65,125,128));
        tf1.setForeground(Color.BLACK);
        l1.add(tf1);

        b1 = new JButton("WITHDRAW");
        b1.setBounds(670, 335, 200, 40);
        b1.setBackground(new Color(65,125,128));
        b1.setForeground(Color.white);
        b1.setFont(new Font("System",Font.BOLD,20));
        b1.addActionListener(this);
        l1.add(b1);
 
        b2 = new JButton("BACK");
        b2.setBounds(670, 395, 200, 40);
        b2.setBackground(new Color(65,125,128));
        b2.setForeground(Color.white);
        b2.setFont(new Font("System",Font.BOLD,20));
        b2.addActionListener(this);
        l1.add(b2);

        setLayout(null);
        setSize(1550, 1080);
        setLocation(0, 0);
        setVisible(true);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new Withdraw("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            String d = tf1.getText();
            int a = Integer.parseInt(d);
            Date date = new Date(System.currentTimeMillis());
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            TimeZone istTimeZone = TimeZone.getTimeZone("Asia/Kolkata");


            if(e.getSource() == b1){
                if (tf1.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "Please enter the amount to withdraw");
                }else{
                    Conn c = new Conn();
                    ResultSet rs = c.statement.executeQuery("select * from dep where pin = '"+pn+"'");
                    int bal = 0;
                    while (rs.next()){
                        if (rs.getString("type").equals("Deposit")){
                            bal = bal + Integer.parseInt(rs.getString("amount"));

                        }else{
                            bal -= Integer.parseInt(rs.getString("amount"));
                        }
                    }

                    if (bal < a){
                        JOptionPane.showMessageDialog(null, "Insufficient Balance. Do check with your account.");
                    }else{
                        c.statement.executeUpdate("insert into dep values ('"+pn+"', '"+date+"','"+timestamp+"','Withdrawl','"+a+"')");
                        JOptionPane.showMessageDialog(null, "Withdrawl of amount Rs."+a+ " Successful");
                        setVisible(false);
                        new main_screen(pn);
                    }
                }
                
            }else if (e.getSource() == b2){
                setVisible(false);
                new main_screen(pn);
            }
        } catch (Exception E) {
            E.printStackTrace();
        }
    }
    
}
