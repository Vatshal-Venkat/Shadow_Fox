package bankmanager;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class SignUp3 extends JFrame implements ActionListener{
    String form;

    JRadioButton r1,r2,r3,r4;

    JCheckBox c1,c2,c3,c4,c5,c6;

    JButton b1,b2;


    SignUp3(String four){
        super("Application Form");

        this.form = four;

        ImageIcon i1 = new ImageIcon("C:/Users/Venkat_Vatshal/OneDrive/Desktop/Shadow_fox/src/icon/bank.png");

        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon img = new ImageIcon(i2);
        JLabel imag = new JLabel(img);
        imag.setBounds(25, 10, 100, 100);
        add(imag);


        JLabel l1 = new JLabel("Application Number: ");
        l1.setBounds(140, 10, 300, 50);
        l1.setFont(new Font("Times New Roman",Font.BOLD,24));
        l1.setForeground(new Color(254,215,165));
        add(l1);

        JLabel l2 = new JLabel(four);
        l2.setBounds(360,10,100,50);
        l2.setFont(new Font("Times New Roman",Font.BOLD,24));
        l2.setForeground(new Color(254,215,165));
        add(l2);

        JLabel l3 = new JLabel("Account Type :");
        l3.setBounds(25,140,200,25);
        l3.setFont(new Font("Times New Roman",Font.BOLD,18));
        l3.setForeground(new Color(254,215,165));
        add(l3);

        r1 = new JRadioButton("Savings Account");
        r1.setBounds(45,180,200,25);
        r1.setFont(new Font("Times New Roman",Font.BOLD,18));
        r1.setForeground(new Color(254,215,165));
        r1.setBackground(new Color(62,22,12));
        add(r1);

        r2 = new JRadioButton("Fixed Deposit");
        r2.setBounds(250,180,200,25);
        r2.setFont(new Font("Times New Roman",Font.BOLD,18));
        r2.setForeground(new Color(254,215,165));
        r2.setBackground(new Color(62,22,12));
        add(r2);

        r3 = new JRadioButton("Current Account");
        r3.setBounds(45,205,200,25);
        r3.setFont(new Font("Times New Roman",Font.BOLD,18));
        r3.setForeground(new Color(254,215,165));
        r3.setBackground(new Color(62,22,12));
        add(r3);

        r4 = new JRadioButton("Reccuring Deposit Account");
        r4.setBounds(250,205,300,25);
        r4.setFont(new Font("Times New Roman",Font.BOLD,18));
        r4.setForeground(new Color(254,215,165));
        r4.setBackground(new Color(62,22,12));
        add(r4);

        ButtonGroup bg1 = new ButtonGroup();
        bg1.add(r1);
        bg1.add(r2);
        bg1.add(r3);
        bg1.add(r4);

        JLabel l4 = new JLabel("Card Number :");
        l4.setBounds(25,255,200,25);
        l4.setFont(new Font("Times New Roman",Font.BOLD,18));
        l4.setForeground(new Color(254,215,165));
        add(l4);

        JLabel l5 = new JLabel("(Your 16-digit card number)");
        l5.setBounds(25,275,200,25);
        l5.setFont(new Font("Times New Roman",Font.PLAIN,12));
        l5.setForeground(new Color(254,215,165));
        add(l5);

        JLabel l6 = new JLabel("XXXX-XXXX-XXXX-9959");
        l6.setBounds(215,255,250,25);
        l6.setFont(new Font("Times New Roman",Font.BOLD,18));
        l6.setForeground(new Color(254,215,165));
        add(l6);

        JLabel l7 = new JLabel("(It would appear on your cheque book/ATM card)");
        l7.setBounds(215,275,300,25);
        l7.setFont(new Font("Times New Roman",Font.PLAIN,12));
        l7.setForeground(new Color(254,215,165));
        add(l7);

        JLabel l8 = new JLabel("PIN :");
        l8.setBounds(25,305,200,25);
        l8.setFont(new Font("Times New Roman",Font.BOLD,18));
        l8.setForeground(new Color(254,215,165));
        add(l8);

        JLabel l9 = new JLabel("****");
        l9.setBounds(215,309,250,25);
        l9.setFont(new Font("Times New Roman",Font.BOLD,18));
        l9.setForeground(new Color(254,215,165));
        add(l9);

        JLabel l10 = new JLabel("(4-digit Password)");
        l10.setBounds(25,325,300,25);
        l10.setFont(new Font("Times New Roman",Font.PLAIN,12));
        l10.setForeground(new Color(254,215,165));
        add(l10);

        JLabel l11 = new JLabel("Services Required");
        l11.setBounds(25,370,250,25);
        l11.setFont(new Font("Times New Roman",Font.BOLD,18));
        l11.setForeground(new Color(254,215,165));
        add(l11);

        c1 = new JCheckBox(" ATM CARD");
        c1.setBounds(45,400,150,25);
        c1.setFont(new Font("Times New Roman",Font.PLAIN,18));
        c1.setForeground(new Color(254,215,165));
        c1.setBackground(new Color(62,22,12));
        add(c1);

        c2 = new JCheckBox(" Mobile Banking");
        c2.setBounds(215,400,250,25);
        c2.setFont(new Font("Times New Roman",Font.PLAIN,18));
        c2.setForeground(new Color(254,215,165));
        c2.setBackground(new Color(62,22,12));
        add(c2);

        c3 = new JCheckBox(" E-Statement");
        c3.setBounds(45,435,150,25);
        c3.setFont(new Font("Times New Roman",Font.PLAIN,18));
        c3.setForeground(new Color(254,215,165));
        c3.setBackground(new Color(62,22,12));
        add(c3);

        c4 = new JCheckBox(" Internet Banking");
        c4.setBounds(215,435,250,25);
        c4.setFont(new Font("Times New Roman",Font.PLAIN,18));
        c4.setForeground(new Color(254,215,165));
        c4.setBackground(new Color(62,22,12));
        add(c4);

        c5 = new JCheckBox(" Cheque Book");
        c5.setBounds(45,470,150,25);
        c5.setFont(new Font("Times New Roman",Font.PLAIN,18));
        c5.setForeground(new Color(254,215,165));
        c5.setBackground(new Color(62,22,12));
        add(c5);

        c6 = new JCheckBox(" E-Mail Alerts");
        c6.setBounds(215,470,250,25);
        c6.setFont(new Font("Times New Roman",Font.PLAIN,18));
        c6.setForeground(new Color(254,215,165));
        c6.setBackground(new Color(62,22,12));
        add(c6);

        JCheckBox c7 = new JCheckBox(" I, hereby declare that all the details above mentioned are true to the best of my knowledege",true);
        c7.setBounds(50,520,500,25);
        c7.setFont(new Font("Times New Roman",Font.PLAIN,12));
        c7.setForeground(new Color(254,215,165));
        c7.setBackground(new Color(62,22,12));
        add(c7);

        JLabel l12 = new JLabel("Page 3");
        l12.setBounds(540,5,50,25);
        l12.setFont(new Font("Cambria",Font.PLAIN,12));
        l12.setForeground(Color.WHITE);
        add(l12);

        b1 = new JButton("Submit");
        b1.setBounds(300,585,100,25);
        b1.setBackground(new Color(62,22,12));
        b1.setForeground(new Color(232,217,196));
        b1.setFont(new Font("Times New Roman",Font.BOLD,20));
        b1.addActionListener(this);
        add(b1);

        b2 = new JButton("Cancel");
        b2.setBounds(140,585,100,25);
        b2.setBackground(new Color(62,22,12));
        b2.setForeground(new Color(232,217,196));
        b2.setFont(new Font("Times New Roman",Font.BOLD,20));
        b2.addActionListener(this);
        add(b2);


        setLayout(null);
        getContentPane().setBackground(new Color(62,22,12));
        setSize(600, 680);
        setLocation(470, 80);
        setUndecorated(true);
        setVisible(true);
    }
    public static void main(String[] args) {
        new SignUp3("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String form = this.form;
        String acc = "";
        if (r1.isSelected()){
            acc = "Savings Account";
        }else if (r2.isSelected()){
            acc = "Fixed Deposit";
        }else if (r3.isSelected()){
            acc = "Current Account";
        }else {
            acc = "Reccuring Deposit Account";
        }

        long r = (long) (Math.random() * 90000000L) + 4009684000000000L;
        String cardno = String.valueOf(r);
        String card = "" + cardno;

        long p = (long) (Math.random() * 9000L)+ 1000L;
        String pn = "" + String.valueOf(p);

        String service = "";
        if (c1.isSelected()){
            service = service+"ATM CARD";
        }else if (c2.isSelected()){
            service = service+"Mobile Banking";
        }else if (c3.isSelected()){
            service = service+"E-Statement";
        }else if (c4.isSelected()){
            service = service+"Internet Banking";
        }else if (c5.isSelected()){
            service = service+"Cheque Book";
        }else if(c6.isSelected()){
            service = service+"Email-Alerets";

        }

        try {
            if (e.getSource() == b1){
                if (acc.equals("") || service.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please Select the mandatory fields");
                    
                }else{
                    Conn con3 = new Conn();
                    String t1 = "INSERT into three values('"+form+"','"+acc+"','"+card+"','"+pn+"','"+service+"')";
                    String t2 = "INSERT into login values ('"+form+"','"+card+"','"+pn+"')";
                    con3.statement.executeUpdate(t2);
                    con3.statement.executeUpdate(t1);
                    setVisible(false);
                    

                    ImageIcon i1 = new ImageIcon("C:/Users/Venkat_Vatshal/OneDrive/Desktop/Shadow_fox/src/icon/Carde.jpeg");
                    Image i2 = i1.getImage().getScaledInstance(420, 100, Image.SCALE_DEFAULT);
                    ImageIcon img = new ImageIcon(i2);
                    JLabel imag = new JLabel(img);
                    imag.setBounds(350, 10, 100, 100);
                    add(imag);
                    JOptionPane.showMessageDialog(null, "Card Number :"+card + "\nPin :"+pn);
                    new main_screen(pn);
                    
                }
            }else if (e.getSource() == b2){
                System.exit(0);
            }
        } catch (Exception E) {
            E.printStackTrace();
        }
    }
}
