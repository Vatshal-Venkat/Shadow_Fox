package bankmanager;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class SignedUp extends JFrame implements ActionListener{
    String form;
    

    JComboBox cb1, cb2, cb3;

    JTextField tf1,tf2,tf3,tf4;

    JRadioButton rb1,rb2,rb3,rb4,rb5,rb6,rb7,rb8;

    JButton b1;


    public SignedUp(String four){
        super("APPLICATION FORM");
        //254,215,165
        
        this.form = four;

        ImageIcon i1 = new ImageIcon("C:/Users/Venkat_Vatshal/OneDrive/Desktop/Shadow_fox/src/icon/bank.png");

        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon img = new ImageIcon(i2);
        JLabel imag = new JLabel(img);
        imag.setBounds(25, 10, 100, 100);
        add(imag);


        JLabel l1 = new JLabel("Application Number: ");
        l1.setBounds(140, 10, 300, 50);
        l1.setFont(new Font("Times New Roman",Font.BOLD,24));
        l1.setForeground(new Color(254,215,165));
        add(l1);

        JLabel l13 = new JLabel(four);
        l13.setBounds(360,10,100,50);
        l13.setFont(new Font("Times New Roman",Font.BOLD,24));
        l13.setForeground(new Color(254,215,165));
        add(l13);



        
        JLabel l2 = new JLabel("Page 2");
        l2.setBounds(540,5,50,25);
        l2.setFont(new Font("Cambria",Font.PLAIN,12));
        l2.setForeground(Color.WHITE);
        add(l2);

        JLabel l3 = new JLabel("Additional Details");
        l3.setBounds(140, 70, 200, 30);
        l3.setFont(new Font("Times New roman",Font.PLAIN,22));
        l3.setForeground(new Color(254,215,165));
        add(l3);
  
        JLabel l4 = new JLabel("Religion");
        l4.setBounds(25,150,150,25);
        l4.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l4.setForeground(new Color(254,215,165));
        add(l4);

        String[] religion = {"","Hindu", "Muslim", "Christian", "Sikh","Other"};
        cb1 = new JComboBox(religion);
        cb1.setBounds(185,150,280,25);
        cb1.setBackground(new Color(62,22,12));
        cb1.setForeground(new Color(254,215,165));
        cb1.setFont(new Font("Times new Roman",Font.PLAIN,20));
        add(cb1);
        
 
        JLabel l5 = new JLabel("Category");
        l5.setBounds(25, 200, 150, 25);
        l5.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l5.setForeground(new Color(254,215,165));
        add(l5);


        String[] category = {"","General", "OBC", "SC", "ST","Other"};
        cb2 = new JComboBox(category);
        cb2.setBounds(185,200,280,25);
        cb2.setBackground(new Color(62,22,12));
        cb2.setForeground(new Color(254,215,165));
        cb2.setFont(new Font("Times new Roman",Font.PLAIN,20));
        add(cb2);

        JLabel l6 = new JLabel("Occupation");
        l6.setBounds(25, 250, 150, 25);
        l6.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l6.setForeground(new Color(254,215,165));
        add(l6);

        tf1 = new JTextField(25);
        tf1.setBounds(185, 250, 280, 25);
        tf1.setBackground(Color.WHITE);
        tf1.setForeground(Color.BLACK);
        tf1.setFont(new Font("Cambria",Font.PLAIN,18));
        add(tf1);
        
        rb1 = new JRadioButton("Government");
        rb1.setBounds(185, 280, 125, 25);
        rb1.setBackground(new Color(62,22,12));
        rb1.setForeground(new Color(254,215,165));
        rb1.setFont(new Font("Times New Roman",Font.PLAIN,18));
        add(rb1);

        rb2 = new JRadioButton("Private");
        rb2.setBounds(335, 280, 80, 25);
        rb2.setBackground(new Color(62,22,12));
        rb2.setForeground(new Color(254,215,165));
        rb2.setFont(new Font("Times New Roman",Font.PLAIN,18));
        add(rb2);

        rb3 = new JRadioButton("Self");
        rb3.setBounds(185, 310, 80, 25);
        rb3.setBackground(new Color(62,22,12));
        rb3.setForeground(new Color(254,215,165));
        rb3.setFont(new Font("Times New Roman",Font.PLAIN,18));
        add(rb3);

        rb4 = new JRadioButton("None");
        rb4.setBounds(335, 310, 80, 25);
        rb4.setBackground(new Color(62,22,12));
        rb4.setForeground(new Color(254,215,165));
        rb4.setFont(new Font("Times New Roman",Font.PLAIN,18));
        add(rb4);

        ButtonGroup bg1 = new ButtonGroup();
        bg1.add(rb1);
        bg1.add(rb2);
        bg1.add(rb3);
        bg1.add(rb4);

        JLabel l7 = new JLabel("Annual Income");
        l7.setBounds(25, 350, 150, 25);
        l7.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l7.setForeground(new Color(254,215,165));
        add(l7);

        tf2 = new JTextField(25);
        tf2.setBounds(185, 350, 280, 25);
        tf2.setBackground(Color.WHITE);
        tf2.setForeground(Color.BLACK);
        tf2.setFont(new Font("Cambria",Font.PLAIN,18));
        add(tf2);

        JLabel l8 =new JLabel("PAN Number");
        l8.setBounds(25, 400, 150, 25);
        l8.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l8.setForeground(new Color(254,215,165));
        add(l8);

        tf3 = new JTextField(25);
        tf3.setBounds(185, 400, 280, 25);
        tf3.setBackground(Color.WHITE);
        tf3.setForeground(Color.BLACK);
        tf3.setFont(new Font("Cambria",Font.PLAIN,18));
        add(tf3);

        JLabel l9 =new JLabel("Aadhar Number");
        l9.setBounds(25, 450, 150, 25);
        l9.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l9.setForeground(new Color(254,215,165));
        add(l9);

        tf4 = new JTextField(25);
        tf4.setBounds(185, 450, 280, 25);
        tf4.setBackground(Color.WHITE);
        tf4.setForeground(Color.BLACK);
        tf4.setFont(new Font("Cambria",Font.PLAIN,18));
        add(tf4);


        JLabel l10 = new JLabel("Education");
        l10.setBounds(25,500,150,25);
        l10.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l10.setForeground(new Color(254,215,165));
        add(l10);

        String[] education = {"", "10th", "12th", "Graduation","Post-Grad","Currently UG", "Currently Studying - School","None"};
        cb3 = new JComboBox(education);
        cb3.setBounds(185, 500, 280, 25);
        cb3.setBackground(new Color(62,22,12));
        cb3.setForeground(new Color(254,215,165));
        cb3.setFont(new Font("Times new Roman",Font.PLAIN,20));
        add(cb3);

        JLabel l11 =new JLabel("Senior Citizen");
        l11.setBounds(25, 540, 150, 25);
        l11.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l11.setForeground(new Color(254,215,165));
        add(l11);

        rb5 = new JRadioButton("Yes");
        rb5.setBounds(200, 540, 150, 25);
        rb5.setBackground(new Color(62,22,12));
        rb5.setForeground(new Color(254,215,165));
        rb5.setFont(new Font("Times New Roman",Font.PLAIN,20));
        add(rb5);

        rb6 = new JRadioButton("No");
        rb6.setBounds(355, 540, 150, 25);
        rb6.setBackground(new Color(62,22,12));
        rb6.setFont(new Font("Times New Roman",Font.PLAIN,20));
        rb6.setForeground(new Color(254,215,165));
        add(rb6);

        ButtonGroup bg2 = new ButtonGroup();
        bg2.add(rb5);
        bg2.add(rb6);

        JLabel l12 = new JLabel("Joint Account");
        l12.setBounds(25, 580, 150, 25);
        l12.setFont(new Font("Times New Roman",Font.PLAIN,20));
        l12.setForeground(new Color(254,215,165));
        add(l12);

        rb7 = new JRadioButton("Yes");
        rb7.setBounds(200, 580, 150, 25);
        rb7.setBackground(new Color(62,22,12));
        rb7.setFont(new Font("Times New Roman",Font.PLAIN,20));
        rb7.setForeground(new Color(254,215,165));
        add(rb7);

        rb8 = new JRadioButton("No");
        rb8.setBounds(355, 580, 150, 25);
        rb8.setBackground(new Color(62,22,12));
        rb8.setFont(new Font("Times New Roman",Font.PLAIN,20));
        rb8.setForeground(new Color(254,215,165));
        add(rb8);

        b1 = new JButton("Next");
        b1.setBounds(365,640,100,25);
        b1.setBackground(new Color(62,22,12));
        b1.setForeground(new Color(232,217,196));
        b1.setFont(new Font("Times NEw Roman",Font.BOLD,20));
        b1.addActionListener(this);
        add(b1);


        setLayout(null);
        setLocation(460, 40);
        getContentPane().setBackground(new Color(62,22,12));
        setSize(600, 720);
        setUndecorated(true);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    public static void main(String[] args) {
        new SignedUp("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String form = this.form;
        String rel = (String) cb1.getSelectedItem();
        String cate = (String) cb2.getSelectedItem();
        String occ = tf1.getText();
        String type = "";
        if(rb1.isSelected()){
            type = "Government";
        }else if (rb2.isSelected()){
            type = "Private";
        }else if (rb3.isSelected()){
            type = "Self";
        }else{
            type = "None";
        }

        String ann = tf2.getText();
        String pan = tf3.getText();
        String aadh = tf4.getText();

        String edu = (String) cb3.getSelectedItem();

        String sen = "";
        if(rb5.isSelected()){
            sen = "Yes";
        }else {
            sen = "No";
        }

        String joint = "";
        if(rb7.isSelected()){
            joint = "Yes";
        }else{
            joint = "No";
        }


        try {
            if (e.getSource() == b1) {
                if (ann.isEmpty() || pan.isEmpty() || aadh.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill the mandatory fields.");
                }else{
                    Conn con2 = new Conn();
                    String s = "INSERT into two values('"+form+"','"+rel+"','"+cate+"','"+occ+"','"+type+"','"+ann+"','"+pan+"','"+aadh+"','"+edu+"','"+sen+"','"+joint+"')";
                    con2.statement.executeUpdate(s);
                    new SignUp3(form);
                    setVisible(false);
                }
            }
        } catch (Exception E) {
            E.printStackTrace();
        }
        
    }
}
