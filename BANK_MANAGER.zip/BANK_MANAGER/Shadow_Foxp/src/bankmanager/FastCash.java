package bankmanager;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;
import javax.swing.*;


public class FastCash extends JFrame implements ActionListener {

    JButton b1,b2,b3,b4,b5,b6,b7;
    String pn;

    public FastCash(String pn) {
        this.pn = pn;
        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icon/AuTuM.png"));
        Image i2 = i1.getImage().getScaledInstance(1550, 1080, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l1 = new JLabel(i3);
        l1.setBounds(0, 0, 1530, 800);
        add(l1);

        JLabel l2 = new JLabel("Select Withdrawl Amount");
        l2.setBounds(450,80,800,150);
        l2.setFont(new Font("System",Font.BOLD,28));
        l2.setForeground(Color.WHITE);
        l1.add(l2);

        b1 = new JButton("Rs.200");
        b1.setBounds(350, 215, 200, 40);
        b1.setFont(new Font("System",Font.BOLD,18));
        b1.setBackground(new Color(65,125,128));
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        l1.add(b1);

        b2 = new JButton("Rs.500");
        b2.setBounds(670, 215, 200, 40);
        b2.setFont(new Font("System",Font.BOLD,18));
        b2.setBackground(new Color(65,125,128));
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);
        l1.add(b2);

        b3 = new JButton("Rs.1000");
        b3.setBounds(350, 275, 200, 40);
        b3.setFont(new Font("System",Font.BOLD,18));
        b3.setBackground(new Color(65,125,128));
        b3.setForeground(Color.WHITE);
        b3.addActionListener(this);
        l1.add(b3);

        b4 = new JButton("Rs.2000");
        b4.setBounds(670, 275, 200, 40);
        b4.setFont(new Font("System",Font.BOLD,18));
        b4.setBackground(new Color(65,125,128));
        b4.setForeground(Color.WHITE);
        b4.addActionListener(this);
        l1.add(b4);

        b5 = new JButton("Rs.3000");
        b5.setBounds(350, 335, 200, 40);
        b5.setFont(new Font("System",Font.BOLD,18));
        b5.setBackground(new Color(65,125,128));
        b5.setForeground(Color.WHITE);
        b5.addActionListener(this);
        l1.add(b5);

        b6 = new JButton("Rs.5000");
        b6.setBounds(670, 335, 200, 40);
        b6.setFont(new Font("System",Font.BOLD,18));
        b6.setBackground(new Color(65,125,128));
        b6.setForeground(Color.WHITE);
        b6.addActionListener(this);
        l1.add(b6);

        b7 = new JButton("BACK");
        b7.setBounds(670, 395, 200, 40);
        b7.setFont(new Font("System",Font.BOLD,18));
        b7.setBackground(new Color(65,125,128));
        b7.setForeground(Color.WHITE);
        b7.addActionListener(this);
        l1.add(b7);

        setLayout(null);
        setVisible(true);
        setLocation(0, 0);
        setSize(1550,1080);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

   
    @Override
public void actionPerformed(ActionEvent e) {
    try {
        if (e.getSource() == b7) {
            new main_screen(pn);
            setVisible(false);
        } else {
            String buttonText = ((JButton)e.getSource()).getText();
            int amount = Integer.parseInt(buttonText.substring(3)); 

            Conn c = new Conn();
            Date date = new Date(System.currentTimeMillis());
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());

            
            int bal = 0;
            try {
                ResultSet rs = c.statement.executeQuery("SELECT * FROM dep WHERE pin = '"+pn+"'");
                
                while (rs.next()) {
                    if (rs.getString("type").equalsIgnoreCase("Deposit")) { 
                        bal += Integer.parseInt(rs.getString("amount"));
                    } else {
                        bal -= Integer.parseInt(rs.getString("amount"));
                    }
                }
            } catch (Exception E) {
                E.printStackTrace();
            }

            
            if (bal < amount) {
                JOptionPane.showMessageDialog(null, "Insufficient Balance");
                return;
            }

           
            try {
                String query = "INSERT INTO dep (pin, date, timestamp, type, amount) VALUES ('" + pn + "', '" + date + "', '" + timestamp + "', 'Withdraw', '" + amount + "')";
                c.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null, "Rs." + amount + " has been debited from your account successfully");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    } catch (Exception E) {
        E.printStackTrace();
    }

    }
    public static void main(String args[]){
        new FastCash("");
    }
}
