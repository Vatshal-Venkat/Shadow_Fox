package bankmanager;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import javax.swing.*;

public class pinEx extends JFrame implements ActionListener {

    JButton b1,b2,b3;
    JPasswordField pf1,pf2;
    String pn;

    pinEx(String pn){
        this.pn = pn;
        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icon/AuTuM.png"));
        Image i2 = i1.getImage().getScaledInstance(1550, 1080, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l1 = new JLabel(i3);
        l1.setBounds(0, 0, 1530, 800);
        add(l1);


        JLabel l2 = new JLabel("CHANGE YOUR PIN :");
        l2.setBounds(475, 100, 500, 35);
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("System",Font.BOLD,22));
        l1.add(l2);

        JLabel l3 = new JLabel("Enter New PIN");
        l3.setBounds(370,170,150,25);
        l3.setForeground(Color.WHITE);
        l3.setFont(new Font("System", Font.BOLD,16));
        l1.add(l3);

        pf1 = new JPasswordField();
        pf1.setBounds(550, 170, 150, 25);
        pf1.setBackground(Color.WHITE);
        pf1.setForeground(Color.BLACK);
        pf1.setFont(new Font("System",Font.BOLD,20));
        l1.add(pf1);

        JLabel l4 = new JLabel("Re-Enter New PIN");
        l4.setBounds(370,220,150,25);
        l4.setForeground(Color.WHITE);
        l4.setFont(new Font("System", Font.BOLD,16));
        l1.add(l4);

        pf2 = new JPasswordField();
        pf2.setBounds(550, 220, 150, 25);
        pf2.setBackground(Color.WHITE);
        pf2.setForeground(Color.BLACK);
        pf2.setFont(new Font("System",Font.BOLD,20));
        l1.add(pf2);

        b1 = new JButton("CHANGE");
        b1.setBounds(670, 335, 200, 40);
        b1.setBackground(new Color(65,125,128));
        b1.setForeground(Color.white);
        b1.setFont(new Font("System",Font.BOLD,20));
        b1.addActionListener(this);
        l1.add(b1);
 
        b2 = new JButton("BACK");
        b2.setBounds(670, 395, 200, 40);
        b2.setBackground(new Color(65,125,128));
        b2.setForeground(Color.white);
        b2.setFont(new Font("System",Font.BOLD,20));
        b2.addActionListener(this);
        l1.add(b2);

        b3 = new JButton("CLEAR");
        b3.setBounds(350,395,200,40);
        b3.setBackground(new Color(65,125,128));
        b3.setForeground(Color.white);
        b3.setFont(new Font("System",Font.BOLD,20));
        b3.addActionListener(this);
        l1.add(b3);

        setLayout(null);
        setSize(1550, 1080);
        setLocation(0, 0);
        setVisible(true);
        setUndecorated(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            String p1 = new String(pf1.getPassword());
            String p2 = new String(pf2.getPassword());

            System.out.println("Entered PINs: " + p1 + ", " + p2);

            if (e.getSource() == b1) {
                if (p1.isEmpty() || p2.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please fill both fields.");
                    return;
                }

                if (!p1.equals(p2)) {
                    JOptionPane.showMessageDialog(this, "Ensure both PINs are correctly entered.");
                    return;
            }

                System.out.println("Current PIN from previous session: " + pn);

                Conn c = new Conn();

            // Debugging: Check if `pn` exists in `login` and `three` before updating
                ResultSet rs1 = c.statement.executeQuery("SELECT * FROM login WHERE pass = '" + pn + "'");
                if (!rs1.next()) {
                    System.out.println("No matching record found in login table.");
                } else {
                    System.out.println("Record found in login table, proceeding with update.");
                }

                ResultSet rs2 = c.statement.executeQuery("SELECT * FROM three WHERE pass = '" + pn + "'");
                if (!rs2.next()) {
                    System.out.println("No matching record found in three table.");
                } else {
                    System.out.println("Record found in three table, proceeding with update.");
                }

            // Corrected column name from "pin" to "pass" in login and three tables
                String q1 = "UPDATE dep SET pin = '" + p1 + "' WHERE pin = '" + pn + "'";
                String q2 = "UPDATE login SET pass = '" + p1 + "' WHERE pass = '" + pn + "'";
                String q3 = "UPDATE three SET pass = '" + p1 + "' WHERE pass = '" + pn + "'";
                

                System.out.println("Executing Query: " + q1);
                System.out.println("Executing Query: " + q2);
                System.out.println("Executing Query: " + q3);

                int rows1 = c.statement.executeUpdate(q1);
                int rows2 = c.statement.executeUpdate(q2);
                int rows3 = c.statement.executeUpdate(q3);


                String balanceQuery = "SELECT SUM(amount) FROM dep WHERE pin = '" + p1 + "'";
                ResultSet rs = c.statement.executeQuery(balanceQuery);
                if (rs.next()) {
                    String updatedBalance = rs.getString(1);
                    JOptionPane.showMessageDialog(this, "Your PIN has been changed.\nUpdated Balance: " + updatedBalance);
                }

                System.out.println("Rows affected: " + rows1 + ", " + rows2 + ", " + rows3);

                if (rows1 > 0 || rows2 > 0 || rows3 > 0) {
                    JOptionPane.showMessageDialog(null, "Your PIN has been successfully changed.");
                    new main_screen(pn);
                    setVisible(false);
                } else {
                    JOptionPane.showMessageDialog(null, "PIN change failed. Check if your current PIN is correct.");
                }
            } else if (e.getSource() == b2) {
                new main_screen(pn);
                setVisible(false);
            } else if (e.getSource() == b3) {
                pf1.setText("");
                pf2.setText("");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new pinEx("");
    }
}
